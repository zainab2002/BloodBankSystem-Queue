/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.resturant12;

import java.util.Scanner;
import javax.swing.SwingUtilities;

/**
 *
 * @author huda-
 */
public class Resturant {

       static Scanner scanner = new Scanner(System.in);
        static Menu menu = new Menu();
        static Order order = new Order();

    public static void main(String[] args) {
     int choice;
 

//GUIrest r = new GUIrest();
//r.setVisible(true);


     menu.enqueueFront("Sushi", 60);
     menu.enqueueFront("Ramen", 45);
     menu.enqueueFront("Tempura", 59);
     menu.enqueueFront("Udon", 70);
     menu.enqueueFront("Teriyaki Chicken", 85);
     menu.enqueueFront("Miso Soup", 35);
     menu.enqueueFront("Gyoza", 40);
     menu.enqueueFront("Tonkatsu", 20);
     
     menu.enqueueRear("Water", 3);
     menu.enqueueRear("Pippse", 10);
        
     
       do{
        System.out.println("Are you an admin or a customer?");
            System.out.println("1. Admin");
            System.out.println("2. Customer");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
             choice = scanner.nextInt();
             
             switch (choice) {
                case 1:
                    adminOptions();
                    break;
                case 2:
                    customerOptions();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
           
    }while(choice!=3);
    }
        
        
        static void adminOptions() {
    System.out.print("Enter username: ");
    String username = scanner.next();
    System.out.print("Enter password: ");
    String password = scanner.next();
            System.out.println("");
     int choice;
    

    if (username.equals("admin") && password.equals("admin")) {
        
    do{
        System.out.println("Welcome, Admin!\n");
        System.out.println("1. Add new food item  ");
        System.out.println("2. Add new Drink item");
        System.out.println("3. Delete food dish from the menu");
        System.out.println("4. View menu");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
         choice = scanner.nextInt();
        scanner.nextLine(); 

        switch (choice) {
            case 1:
                System.out.println("Enter the food item and its price: ");
                String item = scanner.next();
                double price = scanner.nextInt();
                menu.enqueueFront(item, price);
                break;

            case 2: 
                 System.out.println("Enter the drink item and its price: ");
                String drink = scanner.next();
                double dprice = scanner.nextInt();
                menu.enqueueRear(drink, dprice);
                break;
            case 3:
                System.out.println("Enter the postion of the food item that you want to delete: ");
                int num = scanner.nextInt();
               
                menu.dequeueAtPosition(num);
                break;
            case 4:
                menu.displayMenu();
                break;
            case 5:
                System.out.println("Exiting admin page...");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
    while(choice!=5);
    }}
        
      
        
        
        
        
        static void customerOptions() {
    int choice;
    do {
        System.out.println("Welcome, Customer!");
        System.out.println("1. View menu");
        System.out.println("2. Order");
        System.out.println("3. Update order");
        System.out.println("4. Delete order");
        System.out.println("5. Check order");
        System.out.println("6. Get bill");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
        choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                menu.displayMenu();
                break;
            case 2:
                System.out.println("------ Add your order ------");
                System.out.print("Enter food or drink item from the menu: ");
                String foodItem = scanner.nextLine();
                
                // Check if the entered item is available in the menu
                if (menu.isItemAvailable(foodItem)) {
                    int price = (int) menu.getPrice(foodItem);
                    order.ENQueue(foodItem, price);
                    System.out.println("Item added to your order.");
                } else {
                    System.out.println("Error: Item not found in the menu. Please try again.");
                }
                break;
            case 3:
                 System.out.print("Enter the position of the food item that you want to update ");
                int pos = scanner.nextInt();
                pos=pos-1;
                
             
               
                order.updateOrder( pos);
                break;
            case 4:
                order.chickOrder();
               System.out.println("Enter position of the food item that you wnat to delete: ");
               int posToDelete = scanner.nextInt();
               posToDelete= posToDelete-1;
                order.dequeueAtPosition(posToDelete);
                break;
            case 5:
                order.chickOrder();
                break;
            case 6:
                order.displayBill();
                System.out.println("\t Thank you.. ");
                break;
            case 7:
                System.out.println("Exiting customer mode...");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    } while (choice != 7);
}

        

}
