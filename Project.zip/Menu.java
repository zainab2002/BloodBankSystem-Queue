/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.resturant12;
import java.util.*;
/**
 *
 * @author huda-
 */
public class Menu {
    private class Node {
        String name;
        double price;
        Node prev;
        Node next;

        public Node(String name, double price, Node prev, Node next) {
            this.name = name;
            this.price = price;
            this.prev = prev;
            this.next = next;
        }
    }

    private Node front = null;
    private Node rear = null;
    private int numOfMenuItem = 0;
    
    public boolean isEmpty(){
        return numOfMenuItem==0;
    }

    public boolean isItemAvailable(String itemName) {
    Node current = front;
    while (current != null) {
        if (current.name.equalsIgnoreCase(itemName)) {
            return true;
        }
        current = current.next;
    }
    return false;
}

public double getPrice(String itemName) {
    Node current = front;
    while (current != null) {
        if (current.name.equalsIgnoreCase(itemName)) {
            return current.price;
        }
        current = current.next;
    }
    return 0; // Return 0 if item not found (you can handle this differently if needed)
}

    
    
    public void enqueueRear(String name, double price) {
        
        Node newItem = new Node(name, price, rear, null);
        if (rear == null) {
            front = newItem;
        } else {
            rear.next = newItem;
        }
        rear = newItem;
        numOfMenuItem++;
        
    }

    public void enqueueFront(String name, double price) {
        Node newItem = new Node(name, price, null, front);
        if (front == null) {
            rear = newItem;
        } else {
            front.prev = newItem;
        }
        front = newItem;
        numOfMenuItem++;
    }
    
    public void displayMenu() {
    if (isEmpty()) {
        System.out.println("Menu is empty.");
        return;
    }
     int itemNumber = 1; 
   
        System.out.println("-------------------------------------");
         System.out.println("\t\tMenu");
    Node current = front;
    while (current != null) {
       System.out.printf("%-20s %8s%n",itemNumber+" "+ current.name + ":", "SR" + current.price);
        current = current.next;
        itemNumber++; 
    }
    System.out.println("-------------------------------------");
}

    public void dequeueFront() {
    if (isEmpty()) {
        System.out.println("Menu is empty. Nothing to dequeue.");
        return;
    }

    if (numOfMenuItem == 1) {
        front = null;
        rear = null;
    } else {
        front = front.next;
        front.prev = null;
    }

    numOfMenuItem--;
    System.out.println("Item dequeued from the front successfully.");
}

public void dequeueRear() {
    if (isEmpty()) {
        System.out.println("Menu is empty. Nothing to dequeue.");
        return;
    }

    if (numOfMenuItem == 1) {
        front = null;
        rear = null;
    } else {
        rear = rear.prev;
        rear.next = null;
    }

    numOfMenuItem--;
    System.out.println("Item dequeued from the rear successfully.");
}
    
    public void dequeueAtPosition(int position) {
    if (position < 1 || position > numOfMenuItem) {
        System.out.println("Invalid position.");
        return;
    }

    if (numOfMenuItem == 1) {

        dequeueFront();
        return;
    }

    Node current = front;
    for (int i = 1; i < position; i++) {
        current = current.next;
    }

    if (current == front) {
        dequeueFront();
    } else if (current == rear) {

        dequeueRear();
    } else {

        current.prev.next = current.next;
        current.next.prev = current.prev;
        numOfMenuItem--;
        System.out.println("Item dequeued successfully.");
    }
}
    

    
}

