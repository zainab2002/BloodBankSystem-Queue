/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.resturant12;


import static com.mycompany.resturant12.Resturant.menu;
import static com.mycompany.resturant12.Resturant.scanner;

import java.util.Scanner;
/**
 *
 * @author huda-
 */
public class Order {
    private class Node{
    
        private String foodItem;
        private double  itemPrice;
        private Node next;

        public Node(String foodItem, int itemPrice, Node next) {
            this.foodItem = foodItem;
            this.itemPrice = itemPrice;
            this.next = next;
        }
        
        

        public String getFoodItem() {
            return foodItem;
        }

        public void setFoodItem(String foodItem) {
            this.foodItem = foodItem;
        }

        public double getItemPrice() {
            return itemPrice;
        }

        public void setItemPrice(double itemPrice) {
            this.itemPrice = itemPrice;
        }

        public Node getNext() {
            return next;
        }

        public void setNext(Node next) {
            this.next = next;
        }
        
        
       
    
    }
    
    private int numOfFoodItem = 0 ;
    Node front = null;
    Node rear = null;
    
    public int getSize(){
        return numOfFoodItem;
    }
    
    public boolean isEmpty(){
        return numOfFoodItem==0;
    }
    
    public double getTotalPrice(){
    double totalPrice = 0;
    Node current = front;
    
    while(current != null){
        double price = current.getItemPrice();
        totalPrice += price;
        current = current.getNext();
    }
    
    return totalPrice;
}

  public void displayBill(){
      System.out.println("**** order bill ****");
      Node temp = front;
     int itemNumber = 1; 

    System.out.println("------------------------------");
    System.out.println("Item No. \t Item \t Price ");
    System.out.println("------------------------------");
    while (temp != null) {
        System.out.println(itemNumber + "\t\t" + temp.getFoodItem() + "\t" + temp.getItemPrice());
        temp = temp.getNext();
        itemNumber++; 
    }
      
      System.out.println("------------------------------");
      System.out.println("Total: "+ getTotalPrice());
      System.out.println("------------------------------");
      
  }
    public void ENQueue(String foodItem, int itemPrice ) {
        Node newNode = new Node(foodItem, itemPrice, null);
        
        if(isEmpty()){
            front = newNode;
            rear = newNode;
        }
        else{
            rear.setNext(newNode);
            rear=newNode;
        }
        
        numOfFoodItem++;
        System.out.println("added successfully");
        
    }
    
    public void dequeueFront() {
    if (isEmpty()) {
        System.out.println("Order is empty. Cannot dequeue.");
        return;
    }

    front = front.getNext();

    numOfFoodItem--;
    System.out.println("Item dequeued from the front successfully.");
}


    
    public void dequeueAtPosition(int position) {
    if (position < 0 || position >= numOfFoodItem || isEmpty()) {
        System.out.println("Invalid position or order is empty.");
        return;
    }

    if (position == 0) {
        dequeueFront();
        return;
    }

    Node current = front;
    for (int i = 0; i < position - 1; i++) {
        current = current.getNext();
    }


    Node temp = current.getNext();
    current.setNext(temp.getNext());

    if (temp == rear) {
        rear = current;
    }

    numOfFoodItem--;
    System.out.println("Item Deleted  " + position + " successfully.");
}
    

  
    void updateOrder(int pos) {
        
       if(pos < 0 || pos >= numOfFoodItem) {
        System.out.println("Invalid position.");
        return;
    }
    
    System.out.print("Enter new name for the item: ");
    String newName = scanner.next();

    if (!menu.isItemAvailable(newName)) {
        System.out.println("Error: Item not found in the menu.");
        return;
    }

    Node current = front;
    
    for(int i = 0; i < pos; i++) {
        current = current.next;
    }
    
    current.setFoodItem(newName);
    current.setItemPrice(menu.getPrice(newName));
    
    System.out.println("Item updated successfully.");
    }

   

    void chickOrder() {
         
         Node temp = front;
     int itemNumber = 1; 

    System.out.println("------------------------------");
    System.out.println("Item No. \t Item \t Price ");
    System.out.println("------------------------------");
    while (temp != null) {
        System.out.println(itemNumber + "\t\t" + temp.getFoodItem() + "\t" + temp.getItemPrice());
        temp = temp.getNext();
        itemNumber++; 
    }
    }

    
}
